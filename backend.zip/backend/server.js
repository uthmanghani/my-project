require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const { connectDB } = require('./config/db');
const { runMigrations } = require('./utils/migrationRunner');

// Import middleware
const { authenticateToken } = require('./middleware/auth');
const errorHandler = require('./middleware/errorHandler');
const { generalLimiter, authLimiter } = require('./middleware/rateLimiter');

// Import routes
const authRoutes = require('./routes/authRoutes');
const companyRoutes = require('./routes/companyRoutes');
const accountRoutes = require('./routes/accountRoutes');
const customerRoutes = require('./routes/customerRoutes');
const vendorRoutes = require('./routes/vendorRoutes');
const productRoutes = require('./routes/productRoutes');
const invoiceRoutes = require('./routes/invoiceRoutes');
const billRoutes = require('./routes/billRoutes');
const purchaseOrderRoutes = require('./routes/purchaseOrderRoutes');
const recurringBillingRoutes = require('./routes/recurringBillingRoutes');
const journalRoutes = require('./routes/journalRoutes');
const employeeRoutes = require('./routes/employeeRoutes');
const assetRoutes = require('./routes/assetRoutes');
const budgetRoutes = require('./routes/budgetRoutes');
const reportRoutes = require('./routes/reportRoutes');
const auditRoutes = require('./routes/auditRoutes');
const bankAccountRoutes = require('./routes/bankAccountRoutes');
const bankTransactionRoutes = require('./routes/bankTransactionRoutes');
const paymentRoutes = require('./routes/paymentRoutes');
const openingBalanceRoutes = require('./routes/openingBalanceRoutes');
const exportImportRoutes = require('./routes/exportImportRoutes');
const payrollRoutes = require('./routes/payrollRoutes');
const inviteRoutes = require('./routes/inviteRoutes');
const exchangeRateRoutes = require('./routes/exchangeRateRoutes');

// Loaded directly (not just via their routes) so /health can report exactly
// which version of these two files is actually running in this process —
// verifiable from any browser, no shell or git access required.
const bankControllerCheck = require('./controllers/bankController');
const billControllerCheck = require('./controllers/billController');
const companyControllerCheck = require('./controllers/companyController');

const app = express();

// ==================== CONNECT TO DATABASE ====================
connectDB().then(() => runMigrations());

// ==================== MIDDLEWARE ====================
// Security headers (CSP left to the frontend's own hosting config since
// this API serves JSON, not pages)
app.use(helmet());

// Enable CORS for frontend development
// 'file://' was removed â browsers actually send Origin: null for local
// files, not the string 'file://', so it never matched anything and only
// looked like it permitted local-file access.
app.use(cors({
  origin: ['http://localhost:3000', 'http://127.0.0.1:3000', 'http://localhost:5500', 'https://accountrack.onrender.com'],
  credentials: true
}));

// Parse JSON bodies
app.use(express.json());

// Apply rate limiting to all API routes
app.use('/api/', generalLimiter);

// Stricter rate limiting for auth endpoints
app.use('/api/auth/login', authLimiter);
app.use('/api/auth/register', authLimiter);

// ==================== ROUTES ====================
// Public routes
app.use('/api/auth', authRoutes);

// Protected routes (require authentication)
app.use('/api/company', authenticateToken, companyRoutes);
app.use('/api/accounts', authenticateToken, accountRoutes);
app.use('/api/customers', authenticateToken, customerRoutes);
app.use('/api/vendors', authenticateToken, vendorRoutes);
app.use('/api/products', authenticateToken, productRoutes);
app.use('/api/invoices', authenticateToken, invoiceRoutes);
app.use('/api/bills', authenticateToken, billRoutes);
app.use('/api/purchase-orders', authenticateToken, purchaseOrderRoutes);
app.use('/api/recurring-billings', authenticateToken, recurringBillingRoutes);
app.use('/api/journals', authenticateToken, journalRoutes);
app.use('/api/employees', authenticateToken, employeeRoutes);
app.use('/api/assets', authenticateToken, assetRoutes);
app.use('/api/budgets', authenticateToken, budgetRoutes);
app.use('/api/reports', authenticateToken, reportRoutes);
app.use('/api/audit', authenticateToken, auditRoutes);
app.use('/api/bankaccounts', authenticateToken, bankAccountRoutes);
app.use('/api/banktransactions', authenticateToken, bankTransactionRoutes);
app.use('/api/customerpayments', authenticateToken, paymentRoutes);
app.use('/api/vendorpayments', authenticateToken, paymentRoutes);
app.use('/api/openingbalances', authenticateToken, openingBalanceRoutes);
app.use('/api/export', authenticateToken, exportImportRoutes);
app.use('/api/import', authenticateToken, exportImportRoutes);
app.use('/api/payroll', authenticateToken, payrollRoutes);
app.use('/api/invites', inviteRoutes);
app.use('/api/exchange-rates', authenticateToken, exchangeRateRoutes);
app.use('/api/quotes', authenticateToken, require('./routes/quoteRoutes'));

// ==================== HEALTH CHECK ====================
app.get('/health', (req, res) => {
  res.status(200).json({ 
    status: 'OK', 
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || 'development',
    // Visit this endpoint directly in a browser to verify which version of
    // these two files is actually deployed — no shell or git access needed.
    // If bankControllerHasFix or billControllerHasFix show false, the
    // deployed code is NOT the version that was meant to go live.
    deployCheck: {
      bankControllerVersion: bankControllerCheck.__VERSION__ || 'UNKNOWN (no version marker found — likely an old file)',
      bankControllerHasFix: typeof bankControllerCheck.__VERSION__ === 'string',
      billControllerVersion: billControllerCheck.__VERSION__ || 'UNKNOWN (no version marker found — likely an old file)',
      billControllerHasFix: typeof billControllerCheck.__VERSION__ === 'string',
      companyControllerVersion: companyControllerCheck.__VERSION__ || 'UNKNOWN (no version marker found — likely an old file)',
      companyControllerHasFix: typeof companyControllerCheck.__VERSION__ === 'string'
    }
  });
});

// ==================== 404 HANDLER ====================
app.use('*', (req, res) => {
  res.status(404).json({ error: `Route ${req.originalUrl} not found` });
});

// ==================== GLOBAL ERROR HANDLER ====================
app.use(errorHandler);

// ==================== START SERVER ====================
const PORT = process.env.PORT || 5000;
const server = app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`📍 Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`🔗 API base URL: http://localhost:${PORT}/api`);
  console.log(`✅ Health check: http://localhost:${PORT}/health`);
});

// ==================== GRACEFUL SHUTDOWN ====================
const { closeDB } = require('./config/db');
const { startRecurringJob } = require('./utils/recurringJob');
startRecurringJob();
const { startRecurringBillingJob } = require('./utils/recurringBillingJob');
startRecurringBillingJob();

process.on('SIGINT', async () => {
  console.log('🔴 Shutting down gracefully...');
  server.close(async () => {
    await closeDB();
    console.log('🟢 Server stopped');
    process.exit(0);
  });
});

process.on('SIGTERM', async () => {
  console.log('🔴 SIGTERM received. Shutting down...');
  server.close(async () => {
    await closeDB();
    console.log('🟢 Server stopped');
    process.exit(0);
  });
});