const Vendor = require('../models/Vendor');
const { logAudit } = require('../utils/auditLog');
const AppError = require('../utils/AppError');

// Get all vendors
exports.getAll = async (req, res) => {
  try {
    const vendors = await Vendor.find({ companyId: req.user.companyId, isActive: { $ne: false } })
      .sort({ name: 1 });
    res.json(vendors);
  } catch (err) {
    if (err instanceof AppError) return res.status(err.status).json({ error: err.message });
    console.error(err);
    res.status(500).json({ error: 'Something went wrong. Please try again.' });
  }
};

// Get a single vendor
exports.getOne = async (req, res) => {
  try {
    const vendor = await Vendor.findOne({
      companyId: req.user.companyId,
      _id: req.params.id
    });
    if (!vendor) return res.status(404).json({ error: 'Vendor not found' });
    res.json(vendor);
  } catch (err) {
    if (err instanceof AppError) return res.status(err.status).json({ error: err.message });
    console.error(err);
    res.status(500).json({ error: 'Something went wrong. Please try again.' });
  }
};

// Create a new vendor
exports.create = async (req, res) => {
  try {
    const { name, email, phone, address, tin, openingBalance } = req.body;
    const vendor = new Vendor({
      companyId: req.user.companyId,
      name,
      email,
      phone,
      address,
      tin,
      openingBalance: openingBalance || 0
    });
    await vendor.save();
    res.status(201).json(vendor);
  } catch (err) {
    if (err instanceof AppError) return res.status(err.status).json({ error: err.message });
    console.error(err);
    res.status(500).json({ error: 'Something went wrong. Please try again.' });
  }
};

// Update a vendor
exports.update = async (req, res) => {
  try {
    const vendor = await Vendor.findOneAndUpdate(
      { companyId: req.user.companyId, _id: req.params.id },
      req.body,
      { new: true, runValidators: true }
    );
    if (!vendor) return res.status(404).json({ error: 'Vendor not found' });
    res.json(vendor);
  } catch (err) {
    if (err instanceof AppError) return res.status(err.status).json({ error: err.message });
    console.error(err);
    res.status(500).json({ error: 'Something went wrong. Please try again.' });
  }
};

// Delete a vendor
exports.delete = async (req, res) => {
  try {
    const vendor = await Vendor.findOneAndUpdate(
      { companyId: req.user.companyId, _id: req.params.id },
      { isActive: false },
      { new: true }
    );
    if (!vendor) return res.status(404).json({ error: 'Vendor not found' });
    await logAudit(req, 'VENDOR_DEACTIVATED', `Deactivated vendor ${vendor.name}`);
    res.json({ message: 'Vendor deactivated' });
  } catch (err) {
    if (err instanceof AppError) return res.status(err.status).json({ error: err.message });
    console.error(err);
    res.status(500).json({ error: 'Something went wrong. Please try again.' });
  }
};